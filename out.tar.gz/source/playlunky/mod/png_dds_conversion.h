#pragma once

#include <filesystem>

bool ConvertPngToDds(const std::filesystem::path& source, const std::filesystem::path& destination);
