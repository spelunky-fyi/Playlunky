#pragma once

#include <vector>

std::vector<struct DetourEntry> GetDebugDetours();
