#pragma once

#include "sigfun.h"
#include "sigscan.h"

#include <type_traits>

void Attach();
void Detach();
